const Discord = require('discord.js');

module.exports.run = (client, message, args) => {
    errorStaff = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("You need to be a `Senior Staff` Member in the discord.")
    errorTicket = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("This channel is not a ticket!")
    errorRole = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("You need to create a `Senior Staff` Role!")
    worked = new Discord.RichEmbed()
        .setColor("GREEN")
        .setAuthor("This channel has been locked from lower staff!")

    let sRole = message.guild.roles.find(r => r.name === "Senior Staff");
    if (!sRole) return message.channel.send(errorRole)
    if (!message.member.roles.has(sRole.id)) return message.channel.send(errorStaff);

    for (let i in client.tickets) {
        if (message.channel.id !== i) return message.channel.send(errorTicket);
    }
    let stRole = message.guild.roles.find(r => r.name === "Staff");
    message.channel.overwritePermissions(stRole, {
        SEND_MESSAGES: false,
        READ_MESSAGES: false
    })
    message.channel.send(worked)

}
module.exports.config = {
        name: "lock",
        aliases: ["ticketlock"],
        usage: "-lock",
        description: ["Locks a ticket for higher staff only"],
        accessableby: "Staff Members"
}