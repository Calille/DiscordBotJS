const Discord = require('discord.js')
const ms = require('ms');
const chalk = require("chalk");

module.exports.run = (client, message, args) => {

    const useruser = "Created by: " + message.author.username;
    const userurl = message.author.avatarURL;

    let admin = message.member.hasPermission(8)
    let channel = client.channels.find(c => c.name === args[0]);
    let announcementname = args[1]
    let announcementmessage = args.slice(2).join(' ');

    errorChannel = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("You need to specify a channel.")
        .setDescription(`Proper usage -announce #channel (announcementname) (message)`)

    errorAdmin = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("You need to be an admin.")
        .setDescription("Proper usage -announce #channel (announcementname) (message)")

    errorMessage = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("You need to specify a message.")
        .setDescription("Proper usage -announce #channel (announcementname) (message)")

    errorName = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("You need to specify a message name.")
        .setDescription("Proper usage -announce #channel (announcementname) (message)")

    if (!admin) {
        message.channel.send(errorAdmin)
        return
    }
    if (!channel) {
        message.channel.send(errorChannel)
        return
    }
    if (!announcementname) {
        message.channel.send(errorName)
        return
    }
    if (!announcementmessage) {
        message.channel.send(errorMessage)
        return
    }
    cembed = new Discord.RichEmbed()
        .setColor("#e50514")
        .setAuthor(announcementname.replace("_", " "))
        .setFooter(useruser, userurl)
        .setDescription(announcementmessage)
        channel.send(cembed)

    setTimeout(async function() {
        console.log(chalk.white(`[${chalk.green(`ANNOUNCEMENT`)}${chalk.white(`] - New announcement created`)}`));
    }, ms('1s'));
}

module.exports.config = {
    name: "announce",
    aliases: ["tell", "announcement"],
    usage: "-announce <#channel> <announcementname> <announcement>",
    description: ["Puts an announcement in any channel that you want"],
    accessableby: "Staff Members"
}