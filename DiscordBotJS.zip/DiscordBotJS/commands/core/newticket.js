const Discord = require('discord.js');
const ms = require('ms');
const chalk = require("chalk");
const fs = module.require("fs");

module.exports.run = (client, message, args) => {
    var userName = message.author.username;
    var bool = false;

    let nocategory = new Discord.RichEmbed()
        .setColor("#e50914")
        .setDescription(":no_entry: This guild does not have a ticket category set!")
    //tests if the guild has a category id
    let testserver = "651723067915239487";
    if(!client.ticketcategories[message.guild.id] || !message.guild.id === testserver) return message.channel.send(nocategory)

    blacklisted = new Discord.RichEmbed()
        .setColor("RED")
        .setAuthor("You have been blacklisted from creating tickets!")

    if (client.blacklist[message.author.id]) {
        for (let i in client.blacklist) {
            let blacklisttype = client.blacklist[message.author.id].blacklisttype
            if (blacklisttype === "tickets" || blacklisttype === "all") return message.channel.send(blacklisted)
        }
    }

    //tests is the user already has a ticket open
    let dongembed = new Discord.RichEmbed()
        .setColor("#e50914")
        .setDescription(":no_entry: You already have a open ticket!")
    for (let i in client.tickets) {
        let authorid = client.tickets[i].authorid;
        if (message.author.id === authorid) return message.channel.send(dongembed)
    }
    if (bool == true) return;


    const useruser = message.author.username;
    const userid = message.author.discriminator;
    const userurl = message.author.avatarURL;

    //embeds to be sent later
    let checkdms = new Discord.RichEmbed()
        .setColor("GREEN")
        .setAuthor("Ticket started")
        .setDescription(`Check your dms!`)
    message.channel.send(checkdms);
    let cancelticket = new Discord.RichEmbed()
        .setColor("RED")
        .setAuthor("Ticket Cancelled!")
    let ign = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("What is your IGN?")
    let realm = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("What realm are you experiencing this issue on?")
    let issue = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("What is the issue that you are experiencing?")
    let proof = new Discord.RichEmbed()
        .setColor("#e50914")
        .setAuthor("Submit the proof you have for this (use links only or text only)")
        .setDescription("If this is a buycraft issue please put the transaction ID")

    //roles to be assigned to ticket
    errorRole = new Discord.RichEmbed()
    .setColor("#e50914")
    .setAuthor("You need to create a `Staff` and `Senior Staff` Role!")
    let role = message.guild.roles.find(r => r.name === "Perms");
    let role2 = message.guild.roles.find(r => r.name ==='@everyone');
    let role3 = message.guild.roles.find(r => r.name === "BOT");
    if (!role || !role3) return message.channel.send(errorRole) //checks if a staff or senior staff role exist

    //dm questions
    const ID = message.author.id
    const name = message.author
    client.users.get(ID).send(ign).then(() => {
        const filter = m => m.author.id === message.author.id;
        const collector = client.users.get(ID).dmChannel.createMessageCollector(filter, {max: 1, time:180000})
        collector.on("collect", msg => {
            let IGN = msg.content
            client.users.get(ID).send(realm).then(() => {
                const filter = m => m.author.id === message.author.id;
                const collector = client.users.get(ID).dmChannel.createMessageCollector(filter, {max: 1, time:180000})
                collector.on("collect", msg => {
                    let REALM = msg.content
                    client.users.get(ID).send(issue).then(() => {
                        const filter = m => m.author.id === message.author.id;
                        const collector = client.users.get(ID).dmChannel.createMessageCollector(filter, {max: 1, time:180000})
                        collector.on("collect", msg => {
                            let ISSUE = msg.content
                            client.users.get(ID).send(proof).then(() => {
                                const filter = m => m.author.id === message.author.id;
                                const collector = client.users.get(ID).dmChannel.createMessageCollector(filter, {max: 1, time:180000})
                                collector.on("collect", msg => {
                                    let PROOF = msg.content
                                    let confirmation = new Discord.RichEmbed()
                                        .setAuthor("Confirm your ticket")
                                        .setDescription(`**Ticket creator:** ${name} \n**IGN:** ${IGN} \n**Realm:** ${REALM} \n**Issue:** ${ISSUE}\n**Proof:** ${PROOF}\nType **confirm** to create the ticket or type **cancel** to cancel`)
                                        .setThumbnail(`${message.author.avatarURL}`)
                                        .setColor("GREEN")
                                    client.users.get(ID).send(confirmation).then(() => {
                                        const filter = m => m.author.id === message.author.id;
                                        const collector = client.users.get(ID).dmChannel.createMessageCollector(filter, {max: 5, time:60000})
                                        collector.on("collect", msg => {
                                            if (msg.content === "confirm") {
                                                client.users.get(ID).send("Ticket created!")
                                                function createticket() {
                                                    message.guild.createChannel("ticket-" + userName + "#" + message.author.discriminator, "new-general").then(c => {
                                                        c.overwritePermissions(role, {
                                                            SEND_MESSAGES: true,
                                                            READ_MESSAGES: true
                                                        });
                                                        c.overwritePermissions(role3, {
                                                            SEND_MESSAGES: true,
                                                            READ_MESSAGES: true
                                                        });
                                                        c.overwritePermissions(role2, {
                                                            SEND_MESSAGES: false,
                                                            READ_MESSAGES: false
                                                        });
                                                        c.overwritePermissions(message.author, {
                                                            SEND_MESSAGES: true,
                                                            READ_MESSAGES: true
                                                        });
                                                        const ticketEmbed = new Discord.RichEmbed()
                                                            .setAuthor("Thank you for creating a ticket!")
                                                            .setDescription(`**Ticket creator:** ${name} \n**IGN:** ${IGN} \n**Realm:** ${REALM} \n**Issue:** ${ISSUE}\n**Proof:** ${PROOF}`)
                                                            .setThumbnail(`${message.author.avatarURL}`)
                                                            .setColor("GREEN")
                                                            .setTimestamp()

                                                        //sets the category to whatever that guild has it set to
                                                        c.send({embed: ticketEmbed});
                                                        for (let i in client.ticketcategories) {
                                                            let categoryid = client.ticketcategories[i].category;
                                                            c.setParent(categoryid);
                                                        }
                                                        const categoryId = "651723067915239487";

                                                         embedcreate = new Discord.RichEmbed()
                                                             .setColor("GREEN")
                                                             .setAuthor("Done")
                                                             .setDescription(`You successfully created a ticket. See #ticket-${message.author.username}${message.author.discriminator}`)
                                                         message.channel.send(embedcreate);

                                                        const channelid = c.id
                                                        client.tickets[channelid] = {
                                                            authorid: message.author.id,
                                                            authorname: message.author.tag,
                                                            guildid: message.guild.id,
                                                            ticketign: IGN,
                                                            ticketrealm: REALM,
                                                            ticketissue: ISSUE,
                                                        };

                                                        fs.writeFile("./storage/tickets.json", JSON.stringify(client.tickets, null, 4), err => {
                                                            if (err) throw err;
                                                        })
                                                        return
                                                    }).catch(console.error);
                                                }
                                                createticket()
                                                setTimeout(async function () {
                                                    console.log(chalk.white(`[${chalk.green(`TICKET`)}${chalk.white(`] - New ticket opened`)}`));
                                                }, ms('1s'));
                                            }
                                            if (msg.content === "cancel") return client.users.get(ID).send(cancelticket)
                                        })
                                    })
                                })
                            })
                        })
                    })
                })
            })
        })
    })

}
module.exports.config = {
    name: 'new',
    aliases: ["openticket"],
    usage: "-new",
    description: ["Opens a support ticket for our staff team to deal with"],
    accessableby: "Members"
}