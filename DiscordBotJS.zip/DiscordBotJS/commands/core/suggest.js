const Discord = require('discord.js')
const ms = require('ms')
const chalk = require("chalk");
const fs = module.require("fs");

module.exports.run = async (client, message, args) => {
    function capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }

    let suggestionchannel = message.guild.channels.find(c => c.name === "suggestions");

    errorChannel = new Discord.RichEmbed()
        .setColor("RED")
        .setAuthor("Please create a `suggestions` channel")
    if (!suggestionchannel) return message.channel.send(errorChannel)

    serversuggestion = new Discord.RichEmbed()
        .setColor("RED")
        .setAuthor("In one word, please tell me what this suggestion is about. For example 'Prison', or 'Arkham'")
    suggestionquestion = new Discord.RichEmbed()
        .setColor("RED")
        .setAuthor("Now tell me your suggestion!?")
    cancelsuggestion = new Discord.RichEmbed()
        .setColor("RED")
        .setAuthor("Suggestion Cancelled!")
    confirmedsuggestion = new Discord.RichEmbed()
        .setColor("GREEN")
        .setAuthor("Suggestion Sent!")
    blacklisted = new Discord.RichEmbed()
        .setColor("RED")
        .setAuthor("You have been blacklisted from suggestions!")

    if (client.blacklist[message.author.id]) {
        for (let i in client.blacklist) {
            let blacklisttype = client.blacklist[message.author.id].blacklisttype
            if (blacklisttype === "suggestions" || blacklisttype === "all") return message.channel.send(blacklisted)
        }
    }
    const useruser = message.author.username;
    const userurl = message.author.avatarURL;

    if (!client.suggestionnumber[message.guild.id]) {
        client.suggestionnumber[message.guild.id] = {
            number: 1,
        }
        fs.writeFile("./storage/suggestionnumber.json", JSON.stringify(client.suggestionnumber, null, 4), err => {
            if (err) throw err;
        })
    }
    let checkdms = new Discord.RichEmbed()
        .setColor("GREEN")
        .setAuthor("Suggestion started")
        .setDescription(`Check your dms!`)
    message.channel.send(checkdms);

    const ID = message.author.id
    const name = message.author
    client.users.get(ID).send(serversuggestion).then(() => {
        const filter = m => m.author.id === message.author.id;
        const collector = client.users.get(ID).dmChannel.createMessageCollector(filter, {max: 1, time: 180000})
        collector.on("collect", msg => {
                let SERVERSUGGESTION = capitalizeFirstLetter(msg.content)
                client.users.get(ID).send(suggestionquestion).then(() => {
                    const filter = m => m.author.id === message.author.id;
                    const collector = client.users.get(ID).dmChannel.createMessageCollector(filter, {max: 1, time: 180000})
                    collector.on("collect", msg => {
                        let SUGGESTION = msg.content
                            const snumber = client.suggestionnumber[message.guild.id].number;
                            suggestionconfirm = new Discord.RichEmbed()
                                .setColor("GREEN")
                                .setFooter(useruser, userurl)
                                .addField("Suggestion " + "#" + `${snumber}`, "Submitted by " + `${message.author}`)
                                .addField(`Suggested for ${capitalizeFirstLetter(SERVERSUGGESTION)} Realm(s)`, `${SUGGESTION}`)
                                .setDescription("Please type `confirm` or `cancel` to send your suggestion")
                            client.users.get(ID).send(suggestionconfirm).then(() => {
                                const filter = m => m.author.id === message.author.id;
                                const collector = client.users.get(ID).dmChannel.createMessageCollector(filter, {max: 5, time: 60000})
                                collector.on("collect", msg => {
                                    suggestionfinal = new Discord.RichEmbed()
                                        .setColor("RED")
                                        .setFooter(useruser, userurl)
                                        .addField("Suggestion " + "#" + `${snumber}`, "Submitted by " + `${message.author.tag}`)
                                        .addField(`Suggested for ${capitalizeFirstLetter(SERVERSUGGESTION)} Realm(s)`, `${SUGGESTION}`)
                                        .addField("What is your opinion?", "Vote down below to show how you feel about this suggestion!")
                                    if (msg.content === "confirm") {
                                        suggestionchannel.send(suggestionfinal).then(function (message) {
                                            setTimeout(function () {message.react("✅");}, ms("1s"));
                                            setTimeout(function () {message.react("❌");}, ms("2s")); }).catch(function () {});
                                        setTimeout(async function () { console.log(chalk.white(`[${chalk.green(`SUGGESTION`)}${chalk.white(`] - New suggestion created`)}`));}, ms('1s'));
                                        client.users.get(ID).send(confirmedsuggestion)

                                            let newnumber = +client.suggestionnumber[message.guild.id].number+1

                                            client.suggestionnumber[message.guild.id] = {
                                                number: newnumber,
                                            }

                                            fs.writeFile("./storage/suggestionnumber.json", JSON.stringify(client.suggestionnumber, null, 4), err => {
                                                if (err) throw err;
                                            })
                                    }
    if (msg.content === "cancel") return client.users.get(ID).send(cancelsuggestion)
                                })
                            })
                    })
                })
        })
    })
}
module.exports.config = {
    name: "suggest",
    aliases: ["suggestion"],
    usage: ".suggest",
    description: ["Allows you to create a suggestion"],
    accessableby: "Members"
}