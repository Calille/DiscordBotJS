const Discord = require('discord.js');
const ms = require('ms');
const chalk = require("chalk");
const fs = module.require("fs");

module.exports.run = (client, message, args) => {
    errorUser = new Discord.RichEmbed()
        .setColor("RED")
        .setAuthor("Only Marko may proccess this command!")
    errorCategory = new Discord.RichEmbed()
        .setColor("RED")
        .setAuthor("Please specify a category!")
    worked = new Discord.RichEmbed()
        .setColor("GREEN")
        .setAuthor("Ticket category has been set!")

    if (message.author.id !== "133506047049465856") return message.reply(errorUser)
    if (!args[0]) return message.reply(errorCategory)

    client.ticketcategories[message.guild.id] = {
        category: args[0],
    };

    fs.writeFile("./storage/ticketcategories.json", JSON.stringify(client.ticketcategories, null, 4), err => {
        if(err) throw err;
        message.channel.send(worked)
    });
    setTimeout(async function() {
        console.log(chalk.white(`[${chalk.green(`TICKET`)}${chalk.white(`] - New ticket category set`)}`));
    }, ms('1s'));
}
module.exports.config = {
    name: 'setticketcategory',
    aliases: ["ticketcategory"],
    usage: "*setticketcategory <categoryid>",
    description: ["Sets that guilds ticket category"],
    accessableby: "Josh"
}
