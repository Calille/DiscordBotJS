const Discord = require('discord.js');
const {Client, Attachment} = require('discord.js');
const bot = new Discord.Client()
const date = require('date-and-time');
const ms = require('ms');
const chalk = require("chalk");
const fs = require("fs");

module.exports.run = (client, message, args) => {

    for (let i in client.tickets) {
        let ticketign = client.tickets[i].ticketign;
        let ticketrealm = client.tickets[i].ticketrealm;
        let ticketissue = client.tickets[i].ticketissue;
        let guildid = client.tickets[i].guildid;
        let authorid = client.tickets[i].authorid;
        let authorname = client.tickets[i].authorname;

        //checks if the channel is a ticket
        errorTicket = new Discord.RichEmbed()
            .setColor("#e50914")
            .setAuthor("This channel is not a ticket!")
        if (message.channel.id !== i) return message.channel.send(errorTicket);
        //if theres 2 channels with the same id this stops that
        if (guildid !== message.guild.id) return message.channel.send("Your ticket is not in this guild!");

        let bicon = client.user.displayAvatarURL;
        //where ticket transcripts go
        let logdeletechannel = message.guild.channels.find(c => c.name === "ticket-logs");
        let time = message.createdAt;

        errorReason = new Discord.RichEmbed()
            .setColor("#e50914")
            .setAuthor("You need to mention a reason!")
            .setDescription(`Proper usage -close (reason)`)
        //checks if you mentioned a reason
        if (args.length <= 0) {
            message.channel.send(errorReason);
            return
        }
        let closereason = args.join(' ');

        fs.writeFile("./storage/tickets.json", JSON.stringify(client.tickets), err => {
            if(err) throw err;
        })
        //transcript
        var transcript = [];
        message.channel.fetchMessages({limit: 100})
            .then(messages => {
                const filterBy = client.user.id;
                messages = messages.filter(m => m.author.id != filterBy).array();
                let m = messages.sort((b, a) => b.createdTimestamp - a.createdTimestamp);

                m.forEach(msg => {
                    let now = new Date();
                    const edate = date.format(msg.createdAt, 'MM/DD/YYYY h:mm A');

                    transcript.push(`${edate} ${msg.author.tag}: ${msg.content}`);
                })
                //writes the transcript to a file
                fs.writeFile(`./transcripts/transcript-${authorname}.txt`, `[Transcript] ${message.channel.name} \nTicket creator: ${authorname}\nIGN: ${ticketign} \nRealm: ${ticketrealm} \nIssue: ${ticketissue}\nClose Reason: ${closereason}\n\n\n` + transcript.join("\n"), (err) => {
                    if (err) throw err;
                    function closeticket() {
                        const attachment = new Attachment(`./transcripts/transcript-${authorname}.txt`)
                        const embedsend = new Discord.RichEmbed()
                            .setColor("#e50514")
                            .setAuthor(`Your Ticket Info`)
                            .setDescription(`**Ticket creator:** ${authorname} \n**IGN:** ${ticketign} \n**Realm:** ${ticketrealm} \n**Issue:** ${ticketissue}\n**Close Reason:** ${closereason}`)
                            .addField("Closed on", `${time}`)

                        const ticketdeletelogEmbed = new Discord.RichEmbed()
                            .setAuthor("A Ticket has been closed!", bicon)
                            .setDescription(`**Closed By:** ${message.author} \n**Close reason:** ${closereason}\n**Closed on:**\n${time}`)
                            .setThumbnail(`${message.author.avatarURL}`)
                            .setColor("#e50914")
                        logdeletechannel.send({embed: ticketdeletelogEmbed});
                        logdeletechannel.send(attachment)

                        message.channel.delete();

                        client.users.get(authorid).send(embedsend)
                        client.users.get(authorid).send(attachment)
                    }
                    closeticket()
                    //deletes the ticket in currently open tickets
                    delete client.tickets[message.channel.id];
                    fs.writeFile("./storage/tickets.json", JSON.stringify(client.tickets), err => {
                        if(err) throw err;
                    })
                })

                setTimeout(async function () {
                    console.log(chalk.white(`[${chalk.red(`TICKET`)}${chalk.white(`] - New ticket closed`)}`));
                }, ms('1s'));
            })
    }
}


module.exports.config = {
    name: "close",
    aliases: ["closeticket"    ],
    usage: "-close <reason>",
    description: ["Closes a currently open ticket"],
    accessableby: "Members"
}
