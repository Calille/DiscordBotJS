const Discord = require('discord.js')
var logo = "https://cdn.discordapp.com/attachments/651502289944838156/651739022267252746/picturetopeople.org-2ef0a294356bf2936f715993160195c1a7d9a8c37dd224bc2a.png";

module.exports.run = async (bot, message, args) => {

    message.delete();
    if (!args[0]) {
        message.channel.send("Hello, welcome to Prison Lads! Here are the following commands you have access to!").then(m => m.delete(30000));
        message.channel.send('`-new:` Starts the creation of a ticket\n`-save:` Saves a copy of the ticket transcript\n`-suggest:` Starts the creation of a suggestion\n`-bug:` Starts the creation of a bug report').then(m => m.delete(30000));
        let rolestaff = message.guild.roles.find(r => r.name === "Staff");
        let roleseniorstaff = message.guild.roles.find(r => r.name === "Senior Staff");
        if (message.member.roles.has(rolestaff.id) || message.member.roles.has(roleseniorstaff.id)) {
            message.channel.send('`-close:` Closes a currently open ticket\n`-rename:` Renames a ticket channel\n`-adduser:` Adds a user to a ticket\n`-removeuser:` Removes a user from the ticket').then(m => m.delete(30000));
        }
        if (message.member.roles.has(roleseniorstaff.id)) {
            message.channel.send('`-lock:` Locks a ticket from lower staff').then(m => m.delete(30000));
        }
        if (message.member.hasPermission(8)) {
            message.channel.send('`-prefix:` Changes this guilds bot prefix').then(m => m.delete(30000));
        }
        if (message.member.id === "225285776710172672") {
            message.channel.send('`-setticketcategory:` Changes this ticket category').then(m => m.delete(30000));
        }
    }

    if(args[0]) {
        let command = args[0];
        if (bot.commands.has(command)) {
            command = bot.commands.get(command);
            const SHembed = new Discord.RichEmbed()
                .setTimestamp()
                .setColor("#e50914")
                .setAuthor("Bot Help")
                .setDescription(`**Command:** ${command.config.name}\n**Description:** ${command.config.description}\n**Usage:** ${command.config.usage}\n**Accessable by:** ${command.config.accessableby}\n**Aliases:** ${command.config.aliases}`);
            message.channel.send(SHembed).then(m => m.delete(30000));
            return;
        }
    }
    // const embeddefault = new Discord.RichEmbed()
    //     .setTimestamp()
    //     .setThumbnail(logo)
    //     .setColor("#e50914")
    //     .setDescription("Please choose between:\n`Fun`\n`Moderation`\n`Support`\n`(Command)`");
    // switch (args[0]) {
    //     case "fun":
    //         const funembed = new Discord.RichEmbed()
    //             .setTimestamp()
    //             .setColor("#e50914")
    //             .setDescription("**8ball\nascii\navatar\ncalc\nflip\njoke**")
    //         message.channel.send(funembed)
    //         break;
    //     case "moderation":
    //         const moderationembed = new Discord.RichEmbed()
    //             .setTimestamp()
    //             .setColor("#e50914")
    //             .setDescription("**apply\nban\nkick\nlock\nmembercount\nmute\npurge\nrename\naddrole\nremoverole\nserverinfo\nnick\nsetstatus\nshop\nslow\nstats\nunban\nunmute\nweather\nwhois**")
    //         message.channel.send(moderationembed)
    //         break;
    //     case "support":
    //         const supportembed = new Discord.RichEmbed()
    //             .setTimestamp()
    //             .setColor("#e50914")
    //             .setDescription("**announce\nbugreport\nnew\nclose\nevidencechannel\nsuggest\nprefix\nsend\nmcstats\ninactivity**")
    //         message.channel.send(supportembed)
    //         break;
    //     default:
    //         message.channel.send(embeddefault)
    // }
}
module.exports.config = {
    name: "help",
    aliases: ["helpme", "h", "commands"],
    usage: ".help",
    description: ["Helps you with commands, its also the command you're doing now?"],
    accessableby: "Members"
}

// if (args.length > 1) return message.channel.send("Less args msg")
// switch (args[0]) {
//     case "Moderation":
//         let embed11 = new Discord.RichEmbed()
//             .addField(".ban", "ban [user] [reason].")
//             .addField(".kick", "kick [user] [reason].")
//             .addField(".mute", "mute [user] [duration in (m,h,d,y)] [reason].")
//             .addField(".unban", "unban [user + tag or ID].")
//             .addField(".unmute", "unmutes [user + tag or ID].")
//             .addField(".lock", "Locks the current channel, Example: `.lock [duration]`")
//             .addField(".purge", "Delete messages.")
//             .addField(".slow", "Set slowmode, 1 - 120s.")
//             .addField(".stats", "Shows some info about the bot!")
//             .addField(".whois", "Show some userinfo, .whois [mention]")
//             .setColor("#e50914")
//             .setTimestamp()
//         message.channel.send({
//             embed: embed11
//         })
//         message.channel.send("`Moderation Help Page`");
//         break;
//     case "Support":
//         let embed98 = new Discord.RichEmbed()
//             .addField(".announce", ".announce (Message, Admin+)")
//             .addField(".apply", "Shows the ArcadeWars Application links")
//             .addField(".bug", "Report bugs!")
//             .addField(".suggest", ".suggest [suggestion].")
//             .addField(".about", "Shows some info about the bot and the developer.")
//             .addField("-new [subject]", "Create a new ticket")
//             .addField("-close [reason]", "Close the ticket you're currently in")
//             .addField("-add <@user> [#channel]", "Add a user to a ticket")
//             .addField("-info", "Get the info of a ticket")
//             .addField("-rename <name>", "Rename the name of a ticket")
//             .setColor("#e50914")
//             .setTimestamp()
//         message.channel.send({
//             embed: embed98
//         })
//         message.channel.send("**Support Help Page**");
//         break;
//     case "fun":
//         let embed5 = new Discord.RichEmbed()
//             .addField(".joke", "shows random API generated jokes.")
//             .addField(".8ball", "Ask a question and have it answered by the bot.")
//             .addField(".ascii", "Turns text into fancy ascii text.")
//             .addField(".flip", "Flip a coin!")
//             .addField(".calc", "Does some calculations for you.")
//             .addField(".server", "Get API generated information about the server.")
//             .addField(".serverinfo", "Some info about the server.")
//             .addField(".membercount", "Some info about the members on the server.")
//             .addField(".store", "The ArcadeWars Store Link.")
//             .addField(".weather", "Shows some API generated weather information.")
//             .setColor("#e50914")
//             .setTimestamp()
//         message.channel.send({
//             embed: embed5
//         })
//         message.channel.send("Fun Commands Page")
//         break;
//     default:
//         message.channel.send({
//             embed: embed8
//         })
// }