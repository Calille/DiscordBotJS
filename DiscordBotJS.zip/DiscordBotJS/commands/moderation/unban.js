const Discord = require('discord.js')
var logo = "https://cdn.discordapp.com/attachments/651502289944838156/651739022267252746/picturetopeople.org-2ef0a294356bf2936f715993160195c1a7d9a8c37dd224bc2a.png";


module.exports.run = (client, message, args) => {

  if (!message.member.hasPermission('MANAGE_MEMBERS')) {
  const embed2 = new Discord.RichEmbed()
  .setTimestamp()
  .setColor("#e50914")
  .setThumbnail(logo)
  .setDescription('You are missing permission: `MANAGE_MEMBERS` to be able to execute this command!')
       message.channel.send({embed: embed2})
  } else {
    const reason = args.slice(1).join(' ')
    const user = args[0]
    const modlog = client.channels.find(c => c.name === "logs");
    if (!modlog) return message.reply('I cannot find a logs channel')
    if (reason.length < 1) return message.reply('You must supply a reason for the unban.')
    if (!user) return message.reply('You must supply a User Resolvable, such as a user id.').catch(console.error)
    message.guild.unban(user) 
  
  
const embed = new Discord.RichEmbed()
.setAuthor('User unbanned!')
  .setColor("#e50914")
  .setTimestamp()
  .setThumbnail(logo)
  .addField(`**ID:**`,`${args[0]}`)
  .addField(`**Reason:**`,`${reason}`)
  return modlog.send({embed: embed});
 }

}
  
  
  
  module.exports.config = {
    name: 'unban',
    aliases: [],
      usage: "!usage",
      description: [],
      accessableby: "Staff Members"
}