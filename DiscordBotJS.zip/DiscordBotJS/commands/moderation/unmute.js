const fs = require("fs");
const Discord = require('discord.js')

module.exports.run = async (bot, message, args) => {

	let perms = message.member.hasPermission('BAN_MEMBERS');
	let toMute = message.mentions.members.first() || message.guild.members.get(args[0]);
	let role = message.guild.roles.find(r => r.name === "Muted");

	errorPermission = new Discord.RichEmbed()
		.setColor("#e50914")
		.setAuthor("You need to have the `BAN_MEMBERS` permission to use this command!")
		.setDescription("Proper usage .unmute @user")

	errorUser = new Discord.RichEmbed()
		.setColor("#e50914")
		.setAuthor("You need to mention someone to unmute.")
		.setDescription("Proper usage .unmute @user")

	errorMute = new Discord.RichEmbed()
		.setColor("#e50914")
		.setAuthor("User is not muted.")
		.setDescription("Proper usage .unmute @user")

	if (!perms) return message.channel.send(errorPermission)
	if (!toMute) return message.channel.send(errorUser)

	let muting = toMute.roles.has(role.id);
	if (!muting) return message.channel.send(errorMute)

	await toMute.removeRole(role);
	delete bot.mutes[toMute.id];

	fs.writeFile("./storage/mutes.json", JSON.stringify(bot.mutes), err => {
		if(err) throw err;
		console.log(`${toMute.user.tag} has been unmuted`)
	})
		message.channel.send(`${args[0]} is now unmuted.`)

}

module.exports.config = {
	name: "unmute",
	aliases: [],
	usage: ".unmute <user>",
    description: ["Unmutes a currently muted user"],
    accessableby: "Staff Members"
}