const Discord = require('discord.js')
var logo = "https://cdn.discordapp.com/attachments/552318512316678165/567450681208995860/aw.png";

module.exports.run = (client, message, args) => {


    const testEmbed = new Discord.RichEmbed()
        .setThumbnail(logo)
        .setTimestamp()
        .addField(":bust_in_silhouette:  | ArcadeWars Store", `[Click me!](https://buy.arcadewars.net)`, true)

    const arcadeEmbed = new Discord.RichEmbed()
        .setThumbnail(logo)
        .setTimestamp()
        .addField(":bust_in_silhouette:  | ArcadeWars Store", `[Click me!](https://buy.arcadewars.net)`, true)

    const arkhamEmbed = new Discord.RichEmbed()
        .setThumbnail(logo)
        .setTimestamp()
        .addField(":bust_in_silhouette:  | ArcadeWars Store", `[Click me!](https://buy.arkhamnetwork.org/)`, true)

    if (message.guild.id === "582963963814346762") {
        message.channel.send(testEmbed)
    }
    if (message.guild.id === "275779985728602112") {
        message.channel.send(arcadeEmbed)
    }
    if (message.guild.id === "198961272933449737") {
        message.channel.send(arkhamEmbed)
    }

}

module.exports.config = {
    name: "shop",
    aliases: ["store"],
    usage: ".shop",
    description: ["Links you to our store"],
    accessableby: "Members"
}