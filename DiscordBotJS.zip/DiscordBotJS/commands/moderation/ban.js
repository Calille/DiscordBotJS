const Discord = require("discord.js");
var logo = "https://cdn.discordapp.com/attachments/651502289944838156/651739022267252746/picturetopeople.org-2ef0a294356bf2936f715993160195c1a7d9a8c37dd224bc2a.png";

module.exports.run = async (bot, message, args) => {

  if (!message.member.hasPermission('BAN_MEMBERS')) {
    const embed2 = new Discord.RichEmbed()
      .setTimestamp()
      .setColor("#e50914")
      .setThumbnail(logo)
      .setDescription('You are missing permission: `BAN_MEMBERS` to be able to execute this command!')
    message.channel.send({
      embed: embed2
    })
  } else {

    let user = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));
    if (!user) return message.channel.send("Please mention someone!");
    let reason = args.join(" ").slice(22);


    const embed = new Discord.RichEmbed()
      .setAuthor('**User banned**!')
      .setColor("#e50914")
      .setTimestamp()
      .setThumbnail(logo)
      .addField(`**Offender:**`, `${user}`)
      .addField(`**Reason:**`, `${reason}`)


    let incidentchannel = message.guild.channels.find(c => c.name === "logs");
    if (!incidentchannel) return message.channel.send("Can't find log channel.");

    message.guild.member(user).ban(reason);
    incidentchannel.send({
      embed: embed
    })
  }
}

module.exports.config = {
  name: "ban",
  aliases: ["tempban"],
  usage: ".ban <user> <reason>",
  description: ["Bans a user from the discord permanently"],
  accessableby: "Staff Members"
}