const Discord = require("discord.js");
var logo = "https://cdn.discordapp.com/attachments/552318512316678165/567450681208995860/aw.png";

module.exports.run = (client, msg, args) => {
if (msg.channel.type !== "text") return;
const embed2 = new Discord.RichEmbed()
  .setTimestamp()
  .setColor("#e50914")
  .setThumbnail(logo)
  .setDescription('You are missing permission: `BAN_MEMBERS` to be able to execute this command!')
  
if (!msg.channel.permissionsFor(msg.member).has("BAN_MEMBERS")) return msg.channel.send({embed: embed2});
const limit = args[0] ? args[0] : 0;
const embed = new Discord.RichEmbed()
.setTimestamp()
.setColor("#e50914")
.setThumbnail(logo)
.setDescription('The time limit can only be up to 120 seconds.')
if (limit > 120) return msg.channel.send({embed: embed});
var request = require('request');
request({
    url: `https://discordapp.com/api/v6/channels/${msg.channel.id}`,
    method: "PATCH",
    json: {
        rate_limit_per_user: limit
    },
    headers: {
        "Authorization": `Bot ${client.token}`
    },
});
const embed3 = new Discord.RichEmbed()
.setThumbnail(logo)
.setTimestamp()
.setColor("#e50914")
.setDescription("Slowmode removed, members can now send messages without cooldown!")

const embed4 = new Discord.RichEmbed()
.setThumbnail(logo)
.setTimestamp()
.setColor("#e50914")
.setDescription(`Members will then be able to send messages with a **${limit}** cooldown in seconds.`)


if (limit == 0) return msg.channel.send({embed: embed3});
return msg.channel.send({embed: embed4});
};
module.exports.config = {
    name:"slow",
    aliases: ["slowmode"],
    usage: ".slow <delay>",
    description: ["Puts a cooldown between messages for members"],
    accessableby: "Staff Members"
}