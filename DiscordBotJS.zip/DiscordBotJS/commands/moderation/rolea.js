const Discord = require("discord.js");


module.exports.run = async (bot, message, args) => {
  
  if (!message.member.hasPermission("MANAGE_ROLES")) return message.channel.send("You are missing permission: `MANAGE_ROLES`")

  let member = message.guild.member(message.mentions.users.first()) || message.guild.members.get(args[0]);
  if (!member) return message.channel.send("Please mention someone!")
  let role = args.join(" ").slice(22);

  if (!role) return message.reply("Specify a role!");
  let role2 = message.guild.roles.find(r => r.name === role);
  if (!role2) return message.reply("Couldn't find that role.");

  if (member.roles.has(role2.id)) return message.reply("They already have that role.");
  await (member.addRole(role2.id));

  try {
    await member.send(`Congrats, you have been given the role ${role2.name}`)
  } catch (e) {
    console.log(e.stack);
    message.channel.send(`Congrats to <@${member.id}>, they have been given the role ${role2.name}. We tried to DM them, but their DMs are locked.`)
  }
}

module.exports.config = {
  name: "addrole",
  aliases: ["promote", "roleadd"],
  usage: ".addrole <user> <role>",
  description: ["Gives a specificed user a role"],
  accessableby: "Staff Members"
}