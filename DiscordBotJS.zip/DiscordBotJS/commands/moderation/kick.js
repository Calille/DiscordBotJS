const Discord = require('discord.js')


module.exports.run = async (bot, message, args) => {


  if (!message.member.hasPermission('KICK_MEMBERS')) {
		const embed2 = new Discord.RichEmbed()
		.setTimestamp()
		.setColor("#e50914")
		.setThumbnail(logo)
		.setDescription('You are missing permission: `KICK_MEMBERS` to be able to execute this command!')
			 message.channel.send({embed: embed2})
		} else {
    
    let member = message.mentions.members.first();
    if(!member)
      return message.reply("Please mention a valid member of this server");
    if(!member.kickable) 
      return message.reply("You are lacking the permission `KICK_MEMBERS`");

    let reason = args.slice(1).join(' ');
    if(!reason) reason = "No reason provided";
    
    await member.kick(reason)
    .catch(error => message.reply(`Sorry ${message.author} I couldn't kick because of : ${error}`));

  const embed96 = new Discord.RichEmbed()
  .setAuthor('**User kicked**!')
  .setColor("#e50914")
  .setTimestamp()
  .setThumbnail(member.user.displayAvatarURL)
  .addField(`**Offender:**`,`${member.user.tag}`)
  .addField(`**Reason:**`,`${reason}`)
  
    
    let channel = message.guild.channels.find(c => c.name === "logs");
    if(!channel) return message.channel.send("Can't find log channel.");
    channel.send({embed: embed96})
}
}
module.exports.config = {
    name: "kick",
    aliases: ["yeet"],
    usage: ".kick <user> <reason>",
    description: ["Kicks a player from the discord"],
    accessableby: "Staff Members"
}
