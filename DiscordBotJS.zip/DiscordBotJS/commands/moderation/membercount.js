const Discord = require("discord.js")


module.exports.run = (bot, message, args) => {


let member = message.member;
let sicon = message.guild.iconURL;
let humans = member.guild.members.filter(m => !m.user.bot).size;
let bots = member.guild.members.filter(m => m.user.bot).size;
let online = message.guild.members.filter(member => member.user.presence.status == 'online');
let away = message.guild.members.filter(member => member.user.presence.status == 'idle');
let dnd = message.guild.members.filter(member => member.user.presence.status == 'dnd');
let offline = message.guild.members.filter(member => member.user.presence.status == 'offline');
let Embed = new Discord.RichEmbed()
.setAuthor(message.guild.name, sicon)
.setFooter("Member Count")
.setColor("#e50914")
.addField("Total: ", member.guild.memberCount)
.addField("Bot: ", bots)
.addField("Human: ", humans)
.addField(`User status:`,`Do not disturb: ${dnd.size}\nOnline: ${online.size}\nIdle: ${away.size}\nOffline: ${offline.size}`)

message.channel.send(Embed)
}
module.exports.config = {
    name: "membercount",
    aliases: ["servercount", "memberstats"],
    usage: ".membercount",
    description: ["Displays some useful infomation about the users in the discord"],
    accessableby: "Members"
}