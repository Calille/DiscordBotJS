var Discord = require('discord.js')
var math = require('math-expression-evaluator')
module.exports.run = async (bot, message, args) => {

        if (!args[0]) {
            return message.reply('Please give me something to calculate!')
        }
        let result;
        try {
            result = math.eval(args.join(' '));
        } catch (e) { 
            result = 'Error: ("Invalid Input")';   
        }
        const embed = new Discord.RichEmbed()
        .setColor("#e50914")
        .setTitle("Result:")
        .addField('Calculation:', `\`\`\`js\n${args.join(' ')}\`\`\``)
        .addField('Answer:', `\`\`\`js\n${result}\`\`\``);
        message.channel.send(embed); 
}

module.exports.config = {
          name: "calc",
          aliases: ["calculator"],
          usage: ".calc <calculation>",
          description: ["Does calculations for you if you are too lazy to do it yourself"],
          accessableby: "Members"
}
