const Discord = require('discord.js')
var giveMeAJoke = require('give-me-a-joke');
var logo = "https://cdn.discordapp.com/attachments/651502289944838156/651739022267252746/picturetopeople.org-2ef0a294356bf2936f715993160195c1a7d9a8c37dd224bc2a.png";


module.exports.run = (client, message, args) => {


    giveMeAJoke.getRandomDadJoke (function(joke) {
        const embed = new Discord.RichEmbed()
        .setTimestamp()
        .setColor("#e50914")
        .setThumbnail(logo)
        .setTitle("**Random joke**")
        .setDescription(joke)
        message.channel.send({embed: embed})
    });

}

module.exports.config = {
    name: "joke",
    aliases: ["makemelaugh"],
    usage: ".joke",
    description: ["Generates a joke that probably won't make you laugh"],
    accessableby: "Members"
}
