const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
    let user = message.mentions.users.first() || message.author;
    const useruser = "PRLD Bot v1.0 | By Josh#0069";
    const userurl = bot.user.displayAvatarURL;

     let embed = new Discord.RichEmbed()
     .setAuthor(`${user.username}`)
     .setColor("#11a3d6")
     .setImage(user.displayAvatarURL)
     .setFooter(useruser, userurl)
     message.channel.send(embed);
   
 }

module.exports.config = {
    name: "avatar",
    aliases: ["av"],
    usage: ".avatar <user>",
    description: ["Shows a larger image of a users profile picture."],
    accessableby: "Members"
}
