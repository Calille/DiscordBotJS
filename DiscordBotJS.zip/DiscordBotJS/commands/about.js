
const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {


}

module.exports.config = {
    name: "about",
    aliases: ["aboutme"],
    usage: "!usage",
    description: [],
    accessableby: "Members"
}